# pegasus-one

***"pegasus-one a hacking tools library."***
pegasus-one is a kali linux hacking tools installer for termux and other linux distribution. It's package manager for hacker's.
pegasus-one manage large number's of hacking tools that can be installed on single click. Using pegasus-one, you can install all hacking tools in Termux and other Linux based distributions.
pegasus-one can install **more than 370+ kali linux hacking tools**. use `pegasus-one install [tool_name]` command to install any hacking tool.


------------------------------------------------------------------------

## Operating System Requirements

pegasus-one works on any of the following operating systems:<br>
- **Android** (Using the Termux App) <br>
- **Linux** (Linux Based Systems) <br>

------------------------------------------------------------------------

## How to Install

Open the terminal and type following commands.

* `apt update`

* `apt install git`

* `git clone https://github.com/sobri3195/pegasus-one.git`

* `chmod +x pegasus-one/install`

* `sh pegasus-one/install` if not work than use `./pegasus-one/install`

------------------------------------------------------------------------

## How to use pegasus-one ?

### CLI Mode :
`pegasus-one -h` or `pegasus-one help` for help.

Options :
- `pegasus-one install [tool_name]` install any tool.
- `pegasus-one -i [tool_name]` install any tool.
- `pegasus-one search [tool_name]` search any tool.
- `pegasus-one -s [tool_name]` search any tool.
- `pegasus-one list` list all tools.
- `pegasus-one list -a` list all tools.
- `pegasus-one -l` list all tools.
- `pegasus-one -l -a` list all tools.
- `pegasus-one help` get help.
- `pegasus-one -h` get help.

### Menu Mode :

`pegasus-one start` to start pegasus-one menu mode.

Enter a Number for a specific output:
- (1) : To show all available tools and type the number of a tool which you want to install.
- (2) : To show tools category.
- (3) : If you want to update pegasus-one.
- (4) : If you want to know About Us.
- (5) : To exit the tool.

------------------------------------------------------------------------

**Pegasus Hacker**

Created by Letda Kes dr. Muhammad Sobri Maulana, S.Kom, CEH, OSCP, OSCE - Pegasus


